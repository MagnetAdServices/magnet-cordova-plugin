"# magnet-cordova-plugin" 
